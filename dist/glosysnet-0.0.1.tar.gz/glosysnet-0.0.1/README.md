# Neural Net Tool Package

This is a neural net tool package. You can use
[Gitlab-flavored Markdown](https://gitlab.com/nareshkumarAtnPLUS/neural-net-tools.git)
to write your content.

##	run this command to build package
python setup.py sdist bdist_wheel